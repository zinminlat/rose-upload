# [Miss Rose Bot](https://t.me/MissRose_bot)

### Deploy

[![Deploy](https://camo.githubusercontent.com/6979881d5a96b7b18a057083bb8aeb87ba35fc279452e29034c1e1c49ade0636/68747470733a2f2f7777772e6865726f6b7563646e2e636f6d2f6465706c6f792f627574746f6e2e737667)](https://dashboard.heroku.com/new?template=https%3A%2F%2Fgithub.com%2FFayasKKD%2FMiss-Rose-Bot)

### Credits

• [FayasKKD](https://github.com/FayasKKD/Bio) for this Repository 

• [Paul Larsen](https://github.com/PaulSonOfLars) for his [tgbot](https://github.com/PaulSonOfLars/tgbot) Repository and [Miss Rose Bot](https://t.me/MissRose_bot)

• [Dan Tes](https://github.com/delivrance) For his [Pyrogram](https://docs.pyrogram.org/) Library

## Profile

![Rose Profile](https://telegra.ph/file/718d48493d1fb11197d8b.jpg)
